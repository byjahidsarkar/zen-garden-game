import { useCallback } from 'react';
import { WorldMap } from './components/WorldMap';
import { GameScreen } from './components/GameScreen';
import { useGameStore } from './store/gameStore';
import { MAX_LIVES } from './engine/types';
import type { Boosters } from './engine/types';

function App() {
  const screen = useGameStore((s) => s.screen);
  const currentLevel = useGameStore((s) => s.currentLevel);
  const lives = useGameStore((s) => s.lives);
  const boosters = useGameStore((s) => s.boosters);

  const startLevel = useGameStore((s) => s.startLevel);
  const setScreen = useGameStore((s) => s.setScreen);
  const completeLevel = useGameStore((s) => s.completeLevel);
  const nextLevel = useGameStore((s) => s.nextLevel);

  const handlePlay = useCallback((level: number) => {
    if (lives <= 0) return;
    startLevel(level);
  }, [lives, startLevel]);

  const handleExit = useCallback(() => setScreen('map'), [setScreen]);

  const handleLevelComplete = useCallback((stars: number, score: number) => {
    completeLevel(currentLevel, stars, score);
  }, [completeLevel, currentLevel]);

  const handleNextLevel = useCallback(() => {
    nextLevel();
  }, [nextLevel]);

  const handleLivesChanged = useCallback((n: number) => {
    useGameStore.setState({ lives: Math.max(0, Math.min(MAX_LIVES, n)) });
  }, []);

  const handleBoostersChanged = useCallback((b: Boosters) => {
    useGameStore.setState({ boosters: b });
  }, []);

  if (screen === 'game') {
    return (
      <GameScreen
        level={currentLevel}
        boosters={boosters}
        lives={lives}
        onExit={handleExit}
        onLivesChanged={handleLivesChanged}
        onBoostersChanged={handleBoostersChanged}
        onLevelComplete={handleLevelComplete}
        onNextLevel={handleNextLevel}
      />
    );
  }

  return <WorldMap onPlay={handlePlay} />;
}

export default App;
