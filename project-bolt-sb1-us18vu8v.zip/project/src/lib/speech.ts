/**
 * Web Speech API integration for pronouncing Bengali characters.
 * Uses SpeechSynthesis with bn-BD / bn-IN voices when available.
 */

let cachedVoice: SpeechSynthesisVoice | null = null;

function pickBengaliVoice(): SpeechSynthesisVoice | null {
  if (cachedVoice) return cachedVoice;
  if (!('speechSynthesis' in window)) return null;

  const voices = window.speechSynthesis.getVoices();
  // Prefer bn-BD, then bn-IN, then any bn-* voice.
  cachedVoice =
    voices.find((v) => v.lang === 'bn-BD') ??
    voices.find((v) => v.lang === 'bn-IN') ??
    voices.find((v) => v.lang.startsWith('bn')) ??
    null;
  return cachedVoice;
}

// Warm up the voice list (some browsers load asynchronously).
if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
  window.speechSynthesis.onvoiceschanged = () => {
    cachedVoice = null;
    pickBengaliVoice();
  };
}

/**
 * Pronounce a Bengali character using the Web Speech API.
 * Falls back silently if speech synthesis is unavailable.
 */
export function pronounce(text: string): void {
  if (!('speechSynthesis' in window)) return;

  // Cancel any in-progress speech to avoid overlap.
  window.speechSynthesis.cancel();

  const utter = new SpeechSynthesisUtterance(text);
  const voice = pickBengaliVoice();
  if (voice) {
    utter.voice = voice;
    utter.lang = voice.lang;
  } else {
    utter.lang = 'bn-BD';
  }
  utter.rate = 0.85;
  utter.pitch = 1.1;
  utter.volume = 0.9;
  window.speechSynthesis.speak(utter);
}

/** Whether Bengali speech is available on this device. */
export function speechAvailable(): boolean {
  return typeof window !== 'undefined' && 'speechSynthesis' in window;
}
