import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';
import { MAX_LIVES } from '../engine/types';
import type { Boosters, LevelResult } from '../engine/types';

export type Screen = 'map' | 'game';

export type GameState = {
  screen: Screen;
  currentLevel: number;
  highestLevel: number;
  coins: number;
  lives: number;
  levelResults: Record<number, LevelResult>;
  boosters: Boosters;
  startLevel: (n: number) => void;
  completeLevel: (n: number, stars: number, score: number) => void;
  addLives: (n: number) => void;
  addCoins: (n: number) => void;
  addBooster: (key: keyof Boosters, n: number) => void;
  setScreen: (s: Screen) => void;
  nextLevel: () => void;
};

const DEFAULT_BOOSTERS: Boosters = { hammer: 1, shuffle: 1, extraMoves: 1 };

export const useGameStore = create<GameState>()(
  persist(
    (set, get) => ({
      screen: 'map',
      currentLevel: 1,
      highestLevel: 1,
      coins: 0,
      lives: MAX_LIVES,
      levelResults: {},
      boosters: { ...DEFAULT_BOOSTERS },

      startLevel: (n) => {
        if (get().lives <= 0) return;
        set({ currentLevel: n, screen: 'game' });
      },

      completeLevel: (n, stars, score) => set((s) => {
        const prev = s.levelResults[n];
        const bestStars = Math.max(prev?.stars ?? 0, stars);
        const bestScore = Math.max(prev?.score ?? 0, score);
        return {
          levelResults: { ...s.levelResults, [n]: { stars: bestStars, score: bestScore, completed: true } },
          highestLevel: Math.max(s.highestLevel, n + 1),
          coins: s.coins + score,
        };
      }),

      addLives: (n) => set((s) => ({ lives: Math.min(MAX_LIVES, s.lives + n) })),
      addCoins: (n) => set((s) => ({ coins: s.coins + n })),
      addBooster: (key, n) => set((s) => ({ boosters: { ...s.boosters, [key]: s.boosters[key] + n } })),
      setScreen: (s) => set({ screen: s }),

      nextLevel: () => set((s) => ({
        currentLevel: s.currentLevel + 1,
        screen: 'game',
      })),
    }),
    { name: 'bengali-match-save', storage: createJSONStorage(() => localStorage) },
  ),
);
