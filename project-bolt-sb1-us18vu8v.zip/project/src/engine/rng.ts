export class SeededRNG {
  private state: number;
  constructor(seed: number) { this.state = seed >>> 0 || 1; }
  next(): number {
    this.state ^= this.state << 13; this.state ^= this.state >>> 17; this.state ^= this.state << 5; this.state >>>= 0;
    return this.state / 0xffffffff;
  }
  int(min: number, max: number): number { return Math.floor(this.next() * (max - min + 1)) + min; }
  shuffle<T>(arr: T[]): T[] {
    const a = [...arr];
    for (let i = a.length - 1; i > 0; i--) { const j = this.int(0, i); [a[i], a[j]] = [a[j], a[i]]; }
    return a;
  }
}

export function hashSeed(level: number): number {
  let h = 0x811c9dc5; const str = `bengali-match-level-${level}`;
  for (let i = 0; i < str.length; i++) { h ^= str.charCodeAt(i); h = Math.imul(h, 0x01000193); }
  return h >>> 0;
}
