import { SeededRNG, hashSeed } from './rng';
import { CASCADE_DELAY_MS } from './types';
import { SPECIAL_NONE, SPECIAL_STRIPED_H, SPECIAL_STRIPED_V, SPECIAL_WRAPPED, SPECIAL_COLOR_BOMB } from './types';
import type { Board, Cell, Difficulty, Match, Swap, MatchShape } from './types';

let idCounter = 1;
const nextId = () => idCounter++;

export { CASCADE_DELAY_MS };

export function getDifficulty(level: number): Difficulty {
  const rows = 8;
  const cols = 8;
  const tileTypes = Math.min(5 + Math.floor(level / 10), 8);
  const moves = Math.max(15, 30 - Math.floor(level / 5));
  const targetScore = 1000 + level * 500;
  return { rows, cols, tileTypes, moves, targetScore };
}

function wouldMatchAt(board: Board, r: number, c: number, type: number): boolean {
  if (c >= 2 && board[r]?.[c - 1]?.type === type && board[r]?.[c - 2]?.type === type) return true;
  if (r >= 2 && board[r - 1]?.[c]?.type === type && board[r - 2]?.[c]?.type === type) return true;
  return false;
}

export type CascadeStep = {
  matches: Match[];
  cascade: number;
  score: number;
  clearedCells: { r: number; c: number }[];
  specialCreated: { r: number; c: number; special: number; type: number } | null;
};

export class BoardEngine {
  rows: number; cols: number; tileTypes: number;
  board: Board;
  difficulty: Difficulty;
  private rng: SeededRNG;

  constructor(level: number) {
    this.difficulty = getDifficulty(level);
    this.rows = this.difficulty.rows;
    this.cols = this.difficulty.cols;
    this.tileTypes = this.difficulty.tileTypes;
    this.rng = new SeededRNG(hashSeed(level));
    this.board = this.generateBoard();
  }

  private generateBoard(): Board {
    const board: Board = [];
    for (let r = 0; r < this.rows; r++) {
      const row: Cell[] = [];
      for (let c = 0; c < this.cols; c++) {
        let type: number;
        do { type = this.rng.int(0, this.tileTypes - 1); } while (wouldMatchAt(board, r, c, type));
        row.push({ type, id: nextId(), special: SPECIAL_NONE });
      }
      board.push(row);
    }
    return board;
  }

  inBounds(r: number, c: number): boolean { return r >= 0 && r < this.rows && c >= 0 && c < this.cols; }
  getBoard(): Board { return this.board; }

  private swapCells(s: Swap) {
    const a = this.board[s.r1][s.c1];
    this.board[s.r1][s.c1] = this.board[s.r2][s.c2];
    this.board[s.r2][s.c2] = a;
  }

  areAdjacent(s: Swap): boolean {
    const dr = Math.abs(s.r1 - s.r2);
    const dc = Math.abs(s.c1 - s.c2);
    return (dr === 1 && dc === 0) || (dr === 0 && dc === 1);
  }

  trySwap(swap: Swap): boolean {
    if (!this.areAdjacent(swap)) return false;
    const a = this.board[swap.r1][swap.c1];
    const b = this.board[swap.r2][swap.c2];

    if (a.special === SPECIAL_COLOR_BOMB || b.special === SPECIAL_COLOR_BOMB) {
      const bombIsA = a.special === SPECIAL_COLOR_BOMB;
      const targetType = bombIsA ? b.type : a.type;
      this.board[swap.r1][swap.c1] = { type: -1, id: -1, special: SPECIAL_NONE };
      this.board[swap.r2][swap.c2] = { type: -1, id: -1, special: SPECIAL_NONE };
      for (let r = 0; r < this.rows; r++) {
        for (let c = 0; c < this.cols; c++) {
          if (this.board[r][c].type === targetType) {
            this.board[r][c] = { type: -1, id: -1, special: SPECIAL_NONE };
          }
        }
      }
      return true;
    }

    this.swapCells(swap);
    if (this.findMatches().length === 0) {
      this.swapCells(swap);
      return false;
    }
    return true;
  }

  findMatches(): Match[] {
    const rawMatches: { cells: { r: number; c: number }[]; length: number; type: number; horizontal: boolean }[] = [];

    for (let r = 0; r < this.rows; r++) {
      let run = 1;
      for (let c = 1; c <= this.cols; c++) {
        const same = c < this.cols && this.board[r][c].type >= 0 && this.board[r][c].type === this.board[r][c - 1].type;
        if (same) run++;
        else {
          if (run >= 3) {
            const cells: { r: number; c: number }[] = [];
            for (let k = c - run; k < c; k++) cells.push({ r, c: k });
            rawMatches.push({ cells, length: run, type: this.board[r][c - 1].type, horizontal: true });
          }
          run = 1;
        }
      }
    }

    for (let c = 0; c < this.cols; c++) {
      let run = 1;
      for (let r = 1; r <= this.rows; r++) {
        const same = r < this.rows && this.board[r][c].type >= 0 && this.board[r][c].type === this.board[r - 1][c].type;
        if (same) run++;
        else {
          if (run >= 3) {
            const cells: { r: number; c: number }[] = [];
            for (let k = r - run; k < r; k++) cells.push({ r: k, c });
            rawMatches.push({ cells, length: run, type: this.board[r - 1][c].type, horizontal: false });
          }
          run = 1;
        }
      }
    }

    const consumed = new Set<string>();
    const result: Match[] = [];

    for (let i = 0; i < rawMatches.length; i++) {
      for (let j = i + 1; j < rawMatches.length; j++) {
        const m1 = rawMatches[i];
        const m2 = rawMatches[j];
        if (m1.type !== m2.type) continue;
        const set1 = new Set(m1.cells.map((c) => `${c.r},${c.c}`));
        const overlap = m2.cells.filter((c) => set1.has(`${c.r},${c.c}`));
        if (overlap.length > 0) {
          const allCells = [...m1.cells, ...m2.cells];
          const uniqueCells: { r: number; c: number }[] = [];
          const seen = new Set<string>();
          for (const cell of allCells) {
            const key = `${cell.r},${cell.c}`;
            if (!seen.has(key)) { seen.add(key); uniqueCells.push(cell); }
          }
          const key = uniqueCells.map((c) => `${c.r},${c.c}`).sort().join('|');
          if (!consumed.has(key)) {
            consumed.add(key);
            consumed.add(m1.cells.map((c) => `${c.r},${c.c}`).sort().join('|'));
            consumed.add(m2.cells.map((c) => `${c.r},${c.c}`).sort().join('|'));
            const shape: MatchShape = overlap.length >= 2 ? 'T' : 'L';
            result.push({ cells: uniqueCells, length: uniqueCells.length, type: m1.type, horizontal: m1.horizontal, shape });
          }
        }
      }
    }

    for (const m of rawMatches) {
      const key = m.cells.map((c) => `${c.r},${c.c}`).sort().join('|');
      if (!consumed.has(key)) result.push({ ...m, shape: 'line' as MatchShape });
    }

    return result;
  }

  resolveCascades(): { totalScore: number; steps: CascadeStep[] } {
    const steps: CascadeStep[] = [];
    let totalScore = 0;
    let cascade = 0;
    let matches = this.findMatches();

    while (matches.length > 0) {
      cascade++;
      let cascadeScore = 0;
      const cleared = new Set<string>();
      let specialCreated: CascadeStep['specialCreated'] = null;
      const cellsToSpecialize = new Map<string, { r: number; c: number; special: number; type: number }>();

      for (const m of matches) {
        cascadeScore += m.length * 60 + (m.length > 3 ? (m.length - 3) * 120 : 0);
        for (const cell of m.cells) cleared.add(`${cell.r},${cell.c}`);

        if (m.length === 4 && m.shape === 'line') {
          const mid = m.cells[Math.floor(m.cells.length / 2)];
          const special = m.horizontal ? SPECIAL_STRIPED_V : SPECIAL_STRIPED_H;
          cellsToSpecialize.set(`${mid.r},${mid.c}`, { r: mid.r, c: mid.c, special, type: m.type });
          cleared.delete(`${mid.r},${mid.c}`);
        } else if (m.length >= 5 && (m.shape === 'L' || m.shape === 'T')) {
          const mid = m.cells[Math.floor(m.cells.length / 2)];
          cellsToSpecialize.set(`${mid.r},${mid.c}`, { r: mid.r, c: mid.c, special: SPECIAL_WRAPPED, type: m.type });
          cleared.delete(`${mid.r},${mid.c}`);
        } else if (m.length >= 5 && m.shape === 'line') {
          const mid = m.cells[Math.floor(m.cells.length / 2)];
          cellsToSpecialize.set(`${mid.r},${mid.c}`, { r: mid.r, c: mid.c, special: SPECIAL_COLOR_BOMB, type: m.type });
          cleared.delete(`${mid.r},${mid.c}`);
        }
      }

      for (const [, spec] of cellsToSpecialize) {
        this.board[spec.r][spec.c] = { type: spec.type, id: nextId(), special: spec.special };
        specialCreated = spec;
      }

      const toActivate = new Set<string>();
      for (const key of cleared) {
        const [r, c] = key.split(',').map(Number);
        if (this.board[r][c].special > 0) toActivate.add(key);
      }
      for (const key of toActivate) {
        const [r, c] = key.split(',').map(Number);
        const cell = this.board[r][c];
        if (cell.special === SPECIAL_STRIPED_H) {
          for (let cc = 0; cc < this.cols; cc++) cleared.add(`${r},${cc}`);
        } else if (cell.special === SPECIAL_STRIPED_V) {
          for (let rr = 0; rr < this.rows; rr++) cleared.add(`${rr},${c}`);
        } else if (cell.special === SPECIAL_WRAPPED) {
          for (let dr = -1; dr <= 1; dr++) {
            for (let dc = -1; dc <= 1; dc++) {
              const nr = r + dr, nc = c + dc;
              if (this.inBounds(nr, nc)) cleared.add(`${nr},${nc}`);
            }
          }
        }
      }

      cascadeScore *= cascade;
      totalScore += cascadeScore;

      for (const key of cleared) {
        const [r, c] = key.split(',').map(Number);
        this.board[r][c] = { type: -1, id: -1, special: SPECIAL_NONE };
      }

      steps.push({
        matches, cascade, score: cascadeScore,
        clearedCells: Array.from(cleared).map((k) => { const [r, c] = k.split(',').map(Number); return { r, c }; }),
        specialCreated,
      });

      this.applyGravity();
      this.refill();
      matches = this.findMatches();
    }

    return { totalScore, steps };
  }

  private applyGravity() {
    for (let c = 0; c < this.cols; c++) {
      let writeRow = this.rows - 1;
      for (let r = this.rows - 1; r >= 0; r--) {
        if (this.board[r][c].type >= 0) {
          if (writeRow !== r) {
            this.board[writeRow][c] = this.board[r][c];
            this.board[r][c] = { type: -1, id: -1, special: SPECIAL_NONE };
          }
          writeRow--;
        }
      }
    }
  }

  private refill() {
    for (let r = 0; r < this.rows; r++) {
      for (let c = 0; c < this.cols; c++) {
        if (this.board[r][c].type === -1) {
          this.board[r][c] = { type: this.rng.int(0, this.tileTypes - 1), id: nextId(), special: SPECIAL_NONE };
        }
      }
    }
  }

  useHammer(r: number, c: number): { totalScore: number; steps: CascadeStep[] } {
    if (!this.inBounds(r, c)) return { totalScore: 0, steps: [] };
    this.board[r][c] = { type: -1, id: -1, special: SPECIAL_NONE };
    this.applyGravity();
    this.refill();
    return this.resolveCascades();
  }

  useShuffle(): void {
    const types: number[] = [];
    for (let r = 0; r < this.rows; r++) {
      for (let c = 0; c < this.cols; c++) {
        if (this.board[r][c].type >= 0) types.push(this.board[r][c].type);
      }
    }
    const shuffled = this.rng.shuffle(types);
    let i = 0;
    for (let r = 0; r < this.rows; r++) {
      for (let c = 0; c < this.cols; c++) {
        if (this.board[r][c].type >= 0) {
          this.board[r][c] = { type: shuffled[i++], id: nextId(), special: SPECIAL_NONE };
        }
      }
    }
  }

  hasPossibleMove(): boolean {
    for (let r = 0; r < this.rows; r++) {
      for (let c = 0; c < this.cols; c++) {
        if (c < this.cols - 1) {
          this.swapCells({ r1: r, c1: c, r2: r, c2: c + 1 });
          const found = this.findMatches().length > 0;
          this.swapCells({ r1: r, c1: c, r2: r, c2: c + 1 });
          if (found) return true;
        }
        if (r < this.rows - 1) {
          this.swapCells({ r1: r, c1: c, r2: r + 1, c2: c });
          const found = this.findMatches().length > 0;
          this.swapCells({ r1: r, c1: c, r2: r + 1, c2: c });
          if (found) return true;
        }
      }
    }
    return false;
  }
}
