// 32 unique Bengali characters: vowels (অ-ঔ) + consonants (ক-ন)
export const BENGALI_CHARS = [
  'অ', 'আ', 'ই', 'ঈ', 'উ', 'ঊ', 'ঋ', 'এ', 'ঐ', 'ও', 'ঔ',
  'ক', 'খ', 'গ', 'ঘ', 'ঙ', 'চ', 'ছ', 'জ', 'ঝ', 'ঞ',
  'ট', 'ঠ', 'ড', 'ঢ', 'ণ', 'ত', 'থ', 'দ', 'ধ', 'ন', 'প',
];

// 32 distinct color variations — each character gets its own candy color
export const TILE_COLORS = [
  '#ef4444', '#f97316', '#f59e0b', '#eab308', '#84cc16', '#22c55e', '#10b981', '#14b8a6',
  '#06b6d4', '#0ea5e9', '#3b82f6', '#6366f1', '#8b5cf6', '#a855f7', '#d946ef', '#ec4899',
  '#f43f5e', '#fb7185', '#fda4af', '#fbbf24', '#fcd34d', '#fde047', '#a3e635', '#4ade80',
  '#34d399', '#2dd4bf', '#22d3ee', '#38bdf8', '#60a5fa', '#818cf8', '#c084fc', '#e879f9',
];

export const SPECIAL_NONE = 0;
export const SPECIAL_STRIPED_H = 1;
export const SPECIAL_STRIPED_V = 2;
export const SPECIAL_WRAPPED = 3;
export const SPECIAL_COLOR_BOMB = 4;

export type Cell = { type: number; id: number; special: number };
export type Board = Cell[][];
export type Swap = { r1: number; c1: number; r2: number; c2: number };
export type MatchShape = 'line' | 'L' | 'T';
export type Match = { cells: { r: number; c: number }[]; length: number; type: number; horizontal: boolean; shape: MatchShape };
export type Difficulty = { rows: number; cols: number; tileTypes: number; moves: number; targetScore: number };
export type Boosters = { hammer: number; shuffle: number; extraMoves: number };
export type LevelResult = { stars: number; score: number; completed: boolean };
export const MAX_LIVES = 5;
export const CASCADE_DELAY_MS = 300;
