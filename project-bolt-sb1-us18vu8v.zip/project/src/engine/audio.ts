const CHAR_PITCHES = [261.63, 293.66, 329.63, 392.0, 440.0, 523.25, 587.33];

export class AudioManager {
  private ctx: AudioContext | null = null;
  private masterGain: GainNode | null = null;
  sfxGain: GainNode | null = null;
  musicGain: GainNode | null = null;
  sfxOn = true; musicOn = true;
  private musicOsc: OscillatorNode | null = null;
  private musicLfo: OscillatorNode | null = null;
  private started = false;

  private ensure(): AudioContext {
    if (!this.ctx) {
      this.ctx = new AudioContext();
      this.masterGain = this.ctx.createGain(); this.masterGain.gain.value = 0.8; this.masterGain.connect(this.ctx.destination);
      this.sfxGain = this.ctx.createGain(); this.sfxGain.gain.value = 0.5; this.sfxGain.connect(this.masterGain);
      this.musicGain = this.ctx.createGain(); this.musicGain.gain.value = 0.15; this.musicGain.connect(this.masterGain);
    }
    return this.ctx;
  }

  resume() { const ctx = this.ensure(); if (ctx.state === 'suspended') ctx.resume(); }
  toggleSfx(): boolean { this.sfxOn = !this.sfxOn; return this.sfxOn; }
  toggleMusic(): boolean { this.musicOn = !this.musicOn; if (this.musicGain) this.musicGain.gain.value = this.musicOn ? 0.15 : 0; if (this.musicOn) this.startMusic(); return this.musicOn; }

  playMatch(charType: number, cascade = 1, panX = 0) {
    if (!this.sfxOn) return; const ctx = this.ensure();
    const osc = ctx.createOscillator(); const gain = ctx.createGain(); const panner = ctx.createStereoPanner(); const t = ctx.currentTime;
    const basePitch = CHAR_PITCHES[charType % CHAR_PITCHES.length] ?? 261.63;
    const pitch = basePitch * Math.pow(1.0595, (cascade - 1) * 2);
    osc.type = 'triangle'; osc.frequency.setValueAtTime(pitch, t); osc.frequency.exponentialRampToValueAtTime(pitch * 1.5, t + 0.15);
    panner.pan.value = Math.max(-1, Math.min(1, panX));
    gain.gain.setValueAtTime(0, t); gain.gain.linearRampToValueAtTime(0.25, t + 0.01); gain.gain.exponentialRampToValueAtTime(0.001, t + 0.3);
    osc.connect(gain); gain.connect(panner); panner.connect(this.sfxGain!); osc.start(t); osc.stop(t + 0.35);
  }

  playCombo(cascade: number) {
    if (!this.sfxOn) return; const ctx = this.ensure(); const baseFreq = 523.25; const notes = Math.min(cascade, 5);
    for (let i = 0; i < notes; i++) {
      const osc = ctx.createOscillator(); const gain = ctx.createGain(); const t = ctx.currentTime + i * 0.06;
      osc.type = 'sine'; osc.frequency.setValueAtTime(baseFreq * Math.pow(1.0595, i * 4), t);
      gain.gain.setValueAtTime(0, t); gain.gain.linearRampToValueAtTime(0.2, t + 0.01); gain.gain.exponentialRampToValueAtTime(0.001, t + 0.15);
      osc.connect(gain); gain.connect(this.sfxGain!); osc.start(t); osc.stop(t + 0.2);
    }
  }

  playPop() {
    if (!this.sfxOn) return; const ctx = this.ensure(); const osc = ctx.createOscillator(); const gain = ctx.createGain(); const t = ctx.currentTime;
    osc.type = 'sine'; osc.frequency.setValueAtTime(800, t); osc.frequency.exponentialRampToValueAtTime(400, t + 0.08);
    gain.gain.setValueAtTime(0.15, t); gain.gain.exponentialRampToValueAtTime(0.001, t + 0.1);
    osc.connect(gain); gain.connect(this.sfxGain!); osc.start(t); osc.stop(t + 0.12);
  }

  playClick() { this.playPop(); }
  playSwap() {
    if (!this.sfxOn) return; const ctx = this.ensure(); const osc = ctx.createOscillator(); const gain = ctx.createGain(); const t = ctx.currentTime;
    osc.type = 'sine'; osc.frequency.setValueAtTime(300, t); osc.frequency.linearRampToValueAtTime(500, t + 0.1);
    gain.gain.setValueAtTime(0.12, t); gain.gain.exponentialRampToValueAtTime(0.001, t + 0.15);
    osc.connect(gain); gain.connect(this.sfxGain!); osc.start(t); osc.stop(t + 0.2);
  }
  playBooster() {
    if (!this.sfxOn) return; const ctx = this.ensure();
    for (let i = 0; i < 3; i++) { const osc = ctx.createOscillator(); const gain = ctx.createGain(); const t = ctx.currentTime + i * 0.05;
      osc.type = 'triangle'; osc.frequency.setValueAtTime(600 + i * 200, t); gain.gain.setValueAtTime(0.15, t); gain.gain.exponentialRampToValueAtTime(0.001, t + 0.2);
      osc.connect(gain); gain.connect(this.sfxGain!); osc.start(t); osc.stop(t + 0.25); }
  }
  playSpecial() {
    if (!this.sfxOn) return; const ctx = this.ensure(); const osc = ctx.createOscillator(); const gain = ctx.createGain(); const t = ctx.currentTime;
    osc.type = 'sawtooth'; osc.frequency.setValueAtTime(200, t); osc.frequency.exponentialRampToValueAtTime(1200, t + 0.3);
    gain.gain.setValueAtTime(0.1, t); gain.gain.exponentialRampToValueAtTime(0.001, t + 0.4);
    osc.connect(gain); gain.connect(this.sfxGain!); osc.start(t); osc.stop(t + 0.45);
  }
  playWin() {
    if (!this.sfxOn) return; const ctx = this.ensure(); const notes = [523.25, 659.25, 783.99, 1046.5];
    for (let i = 0; i < notes.length; i++) { const osc = ctx.createOscillator(); const gain = ctx.createGain(); const t = ctx.currentTime + i * 0.12;
      osc.type = 'triangle'; osc.frequency.setValueAtTime(notes[i], t); gain.gain.setValueAtTime(0.2, t); gain.gain.exponentialRampToValueAtTime(0.001, t + 0.4);
      osc.connect(gain); gain.connect(this.sfxGain!); osc.start(t); osc.stop(t + 0.5); }
  }
  playLose() {
    if (!this.sfxOn) return; const ctx = this.ensure(); const osc = ctx.createOscillator(); const gain = ctx.createGain(); const t = ctx.currentTime;
    osc.type = 'sawtooth'; osc.frequency.setValueAtTime(400, t); osc.frequency.exponentialRampToValueAtTime(100, t + 0.6);
    gain.gain.setValueAtTime(0.15, t); gain.gain.exponentialRampToValueAtTime(0.001, t + 0.7);
    osc.connect(gain); gain.connect(this.sfxGain!); osc.start(t); osc.stop(t + 0.8);
  }
  startMusic() {
    if (this.started || !this.musicOn) return; const ctx = this.ensure(); this.started = true;
    this.musicOsc = ctx.createOscillator(); this.musicLfo = ctx.createOscillator(); const lfoGain = ctx.createGain();
    this.musicOsc.type = 'sine'; this.musicOsc.frequency.value = 130.81;
    this.musicLfo.type = 'sine'; this.musicLfo.frequency.value = 0.1; lfoGain.gain.value = 0.05;
    this.musicLfo.connect(lfoGain); lfoGain.connect(this.musicGain!.gain); this.musicOsc.connect(this.musicGain!);
    this.musicOsc.start(); this.musicLfo.start();
  }
  stopMusic() { if (this.musicOsc) { this.musicOsc.stop(); this.musicOsc = null; } if (this.musicLfo) { this.musicLfo.stop(); this.musicLfo = null; } this.started = false; }
}

export const audio = new AudioManager();
