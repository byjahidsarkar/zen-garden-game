import { useRef, useEffect, useState, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronLeft, Heart, Star, Zap, Shuffle as ShuffleIcon, Hammer } from 'lucide-react';
import { BoardEngine, getDifficulty, CASCADE_DELAY_MS } from '../engine/board';
import type { Board, Boosters } from '../engine/types';
import { Tile } from './Tile';

type FloatScore = { id: number; x: number; y: number; value: number };
const COMBO_LABELS: Record<number, string> = { 2: 'Great!', 3: 'Amazing!', 4: 'Awesome!', 5: 'Incredible!', 6: 'Unbelievable!', 7: 'Legendary!' };
const comboLabel = (c: number) => COMBO_LABELS[Math.min(c, 7)] ?? 'Legendary!';

type Props = {
  level: number;
  boosters: Boosters;
  lives: number;
  onExit: () => void;
  onLivesChanged: (n: number) => void;
  onBoostersChanged: (b: Boosters) => void;
  onLevelComplete: (stars: number, score: number) => void;
  onNextLevel: () => void;
};

type DragState = { startR: number; startC: number; startX: number; startY: number; pointerId: number } | null;

export function GameScreen(props: Props) {
  const { level, boosters, lives } = props;
  const engineRef = useRef<BoardEngine | null>(null);
  const [board, setBoard] = useState<Board>([]);
  const [rows, setRows] = useState(8);
  const [cols, setCols] = useState(8);
  const [score, setScore] = useState(0);
  const [moves, setMoves] = useState(30);
  const [targetScore, setTargetScore] = useState(1000);
  const [gameState, setGameState] = useState<'playing' | 'won' | 'lost'>('playing');
  const [floatScores, setFloatScores] = useState<FloatScore[]>([]);
  const [comboDisplay, setComboDisplay] = useState<number | null>(null);
  const [comboLabelDisplay, setComboLabelDisplay] = useState<string | null>(null);
  const [shaking, setShaking] = useState(false);
  const [activeBooster, setActiveBooster] = useState<'hammer' | null>(null);
  const [isResolving, setIsResolving] = useState(false);
  const [boardReady, setBoardReady] = useState(false);
  const [dragVisual, setDragVisual] = useState<{ r: number; c: number; x: number; y: number } | null>(null);
  const [swapBounce, setSwapBounce] = useState<{ r1: number; c1: number; r2: number; c2: number } | null>(null);
  const boardRef = useRef<HTMLDivElement>(null);
  const dragStateRef = useRef<DragState>(null);
  const floatIdRef = useRef(1);
  const isResolvingRef = useRef(false);

  useEffect(() => {
    const engine = new BoardEngine(level);
    engineRef.current = engine;
    const diff = getDifficulty(level);
    engine.resolveCascades();
    setBoard(engine.getBoard().map((r) => [...r]));
    setRows(engine.rows);
    setCols(engine.cols);
    setScore(0);
    setMoves(diff.moves);
    setTargetScore(diff.targetScore);
    setGameState('playing');
    setBoardReady(true);
    return () => { setBoardReady(false); };
  }, [level]);

  const getCellSize = useCallback(() => {
    if (!boardRef.current) return 40;
    const rect = boardRef.current.getBoundingClientRect();
    return Math.min(rect.width / cols, rect.height / rows);
  }, [cols, rows]);

  const handleSwap = useCallback(async (r1: number, c1: number, r2: number, c2: number) => {
    const engine = engineRef.current;
    if (!engine || isResolvingRef.current) return;

    const success = engine.trySwap({ r1, c1, r2, c2 });
    if (!success) {
      setSwapBounce({ r1, c1, r2, c2 });
      setTimeout(() => setSwapBounce(null), 450);
      return;
    }

    isResolvingRef.current = true;
    setIsResolving(true);
    setMoves((m) => m - 1);
    setBoard(engine.getBoard().map((r) => [...r]));

    const { totalScore, steps } = engine.resolveCascades();

    for (const step of steps) {
      if (step.cascade >= 2) {
        setComboDisplay(step.cascade);
        setComboLabelDisplay(comboLabel(step.cascade));
        setTimeout(() => setComboDisplay(null), 1200);
        setTimeout(() => setComboLabelDisplay(null), 1500);
      }
      setShaking(true);
      setTimeout(() => setShaking(false), 400);

      if (step.matches.length > 0) {
        const mid = step.matches[0].cells[Math.floor(step.matches[0].cells.length / 2)];
        const rect = boardRef.current?.getBoundingClientRect();
        if (rect) {
          const cellW = rect.width / cols;
          const cellH = rect.height / rows;
          const id = floatIdRef.current++;
          setFloatScores((fs) => [...fs, { id, x: mid.c * cellW + cellW / 2, y: mid.r * cellH, value: step.score }]);
          setTimeout(() => setFloatScores((fs) => fs.filter((f) => f.id !== id)), 1000);
        }
      }
      setBoard(engine.getBoard().map((r) => [...r]));
      await new Promise((res) => setTimeout(res, CASCADE_DELAY_MS));
    }

    const newScore = score + totalScore;
    setScore(newScore);

    if (newScore >= targetScore) {
      setGameState('won');
      const stars = newScore >= targetScore * 1.5 ? 3 : newScore >= targetScore * 1.2 ? 2 : 1;
      props.onLevelComplete(stars, newScore);
    } else if (moves - 1 <= 0) {
      setGameState('lost');
      props.onLivesChanged(lives - 1);
    }

    if (!engine.hasPossibleMove()) {
      engine.useShuffle();
      setBoard(engine.getBoard().map((r) => [...r]));
    }

    isResolvingRef.current = false;
    setIsResolving(false);
  }, [score, targetScore, moves, lives, props, cols, rows]);

  const handlePointerDown = useCallback((e: React.PointerEvent, r: number, c: number) => {
    if (isResolvingRef.current || gameState !== 'playing') return;
    const engine = engineRef.current;
    if (!engine) return;
    if (engine.getBoard()[r][c].type < 0) return;

    if (activeBooster === 'hammer') {
      if (!props.boosters.hammer) return;
      const { totalScore } = engine.useHammer(r, c);
      setBoard(engine.getBoard().map((rr) => [...rr]));
      setScore((s) => s + totalScore);
      props.onBoostersChanged({ ...props.boosters, hammer: props.boosters.hammer - 1 });
      setActiveBooster(null);
      return;
    }

    const ds: DragState = { startR: r, startC: c, startX: e.clientX, startY: e.clientY, pointerId: e.pointerId };
    dragStateRef.current = ds;
    setDragVisual({ r, c, x: 0, y: 0 });
    try { (e.target as HTMLElement).setPointerCapture(e.pointerId); } catch { /* ignore */ }
  }, [gameState, activeBooster, props]);

  const handlePointerMove = useCallback((e: React.PointerEvent) => {
    const ds = dragStateRef.current;
    if (!ds || ds.pointerId !== e.pointerId) return;
    setDragVisual({ r: ds.startR, c: ds.startC, x: e.clientX - ds.startX, y: e.clientY - ds.startY });
  }, []);

  const handlePointerUp = useCallback((e: React.PointerEvent) => {
    const ds = dragStateRef.current;
    if (!ds || ds.pointerId !== e.pointerId) return;
    dragStateRef.current = null;
    setDragVisual(null);

    const dx = e.clientX - ds.startX;
    const dy = e.clientY - ds.startY;
    const cellSize = getCellSize();
    const threshold = cellSize * 0.3;

    if (Math.abs(dx) < threshold && Math.abs(dy) < threshold) return;

    let targetR = ds.startR;
    let targetC = ds.startC;
    if (Math.abs(dx) > Math.abs(dy)) targetC += dx > 0 ? 1 : -1;
    else targetR += dy > 0 ? 1 : -1;

    const engine = engineRef.current;
    if (!engine || !engine.inBounds(targetR, targetC)) return;
    handleSwap(ds.startR, ds.startC, targetR, targetC);
  }, [getCellSize, handleSwap]);

  const handleShuffle = useCallback(() => {
    if (!props.boosters.shuffle || isResolvingRef.current) return;
    const engine = engineRef.current;
    if (!engine) return;
    engine.useShuffle();
    setBoard(engine.getBoard().map((r) => [...r]));
    props.onBoostersChanged({ ...props.boosters, shuffle: props.boosters.shuffle - 1 });
  }, [props]);

  const handleExtraMoves = useCallback(() => {
    if (!props.boosters.extraMoves || isResolvingRef.current || gameState !== 'playing') return;
    setMoves((m) => m + 5);
    props.onBoostersChanged({ ...props.boosters, extraMoves: props.boosters.extraMoves - 1 });
  }, [props, gameState]);

  const progress = Math.min(100, (score / targetScore) * 100);
  const stars = score >= targetScore * 1.5 ? 3 : score >= targetScore * 1.2 ? 2 : score >= targetScore ? 1 : 0;

  return (
    <div
      className={`game-container bg-gradient-to-b from-slate-900 via-indigo-950 to-slate-900 flex flex-col ${shaking ? 'animate-screen-shake' : ''}`}
      onPointerMove={handlePointerMove}
      onPointerUp={handlePointerUp}
      onPointerCancel={handlePointerUp}
    >
      <div className="flex items-center justify-between px-4 py-3 bg-black/30 backdrop-blur-sm z-30">
        <button onClick={() => props.onExit()} className="w-9 h-9 rounded-full bg-white/10 flex items-center justify-center text-white hover:bg-white/20 transition-colors">
          <ChevronLeft className="w-5 h-5" />
        </button>
        <div className="flex-1 mx-3">
          <div className="flex items-center justify-between mb-1">
            <span className="text-white font-display font-bold text-sm">Level {level}</span>
            <span className="text-cyan-300 font-display font-bold text-sm">{score.toLocaleString()} / {targetScore.toLocaleString()}</span>
          </div>
          <div className="h-3 bg-black/40 rounded-full overflow-hidden">
            <motion.div className="h-full bg-gradient-to-r from-cyan-400 to-teal-400 rounded-full" animate={{ width: `${progress}%` }} transition={{ type: 'spring', stiffness: 120, damping: 20 }} />
          </div>
        </div>
        <div className="flex items-center gap-1">
          {[0, 1, 2].map((i) => <Star key={i} className={`w-5 h-5 ${i < stars ? 'text-amber-400 fill-amber-400' : 'text-white/20'}`} />)}
        </div>
      </div>

      <div className="flex items-center justify-between px-4 py-2 bg-black/15 z-30">
        <div className="flex items-center gap-1 text-white"><Heart className="w-4 h-4 text-red-400" /><span className="font-display font-bold text-sm">{lives}</span></div>
        <div className="flex items-center gap-1 text-white"><Zap className="w-4 h-4 text-cyan-400" /><span className="font-display font-bold text-sm">{moves} moves</span></div>
      </div>

      <div className="flex-1 flex items-center justify-center p-2 relative overflow-hidden">
        <div
          ref={boardRef}
          className="relative grid gap-1 rounded-2xl bg-black/25 p-2 z-10"
          style={{
            display: 'grid',
            gridTemplateColumns: `repeat(${cols}, 1fr)`,
            gridTemplateRows: `repeat(${rows}, 1fr)`,
            width: '100%',
            maxWidth: 'min(100%, calc(100dvh * 0.65))',
            aspectRatio: `${cols} / ${rows}`,
          }}
        >
          <AnimatePresence>
            {boardReady && board.length > 0 && board.map((row, r) =>
              row.map((cell, c) => {
                const isDragging = dragVisual?.r === r && dragVisual?.c === c;
                const dragOffset = isDragging && dragVisual ? { x: dragVisual.x, y: dragVisual.y } : null;
                const bounceOffset = swapBounce
                  ? (swapBounce.r1 === r && swapBounce.c1 === c)
                    ? { x: (swapBounce.c2 - swapBounce.c1) * 12, y: (swapBounce.r2 - swapBounce.r1) * 12 }
                    : (swapBounce.r2 === r && swapBounce.c2 === c)
                    ? { x: (swapBounce.c1 - swapBounce.c2) * 12, y: (swapBounce.r1 - swapBounce.r2) * 12 }
                    : null
                  : null;
                return (
                  <Tile
                    key={cell.id}
                    cell={cell}
                    dragging={isDragging}
                    dragOffset={dragOffset ?? bounceOffset}
                    onPointerDown={(e) => handlePointerDown(e, r, c)}
                  />
                );
              })
            )}
          </AnimatePresence>
        </div>

        <AnimatePresence>
          {floatScores.map((fs) => (
            <motion.div
              key={fs.id}
              initial={{ opacity: 0, y: 0, scale: 0.5 }}
              animate={{ opacity: 1, y: -50, scale: 1.2 }}
              exit={{ opacity: 0, y: -70 }}
              transition={{ duration: 0.8 }}
              className="absolute z-50 pointer-events-none font-display font-bold text-2xl"
              style={{ left: fs.x, top: fs.y, color: '#5eead4', textShadow: '0 2px 8px rgba(0,0,0,0.6)', transform: 'translate(-50%, -50%)' }}
            >
              +{fs.value}
            </motion.div>
          ))}
        </AnimatePresence>
      </div>

      <AnimatePresence>
        {comboDisplay && (
          <motion.div initial={{ scale: 0, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0, opacity: 0 }} className="absolute top-1/3 left-1/2 -translate-x-1/2 z-50 pointer-events-none">
            <div className="bg-gradient-to-r from-amber-400 to-orange-500 rounded-full px-6 py-2 shadow-2xl">
              <p className="font-display font-bold text-white text-2xl">{comboDisplay}x COMBO!</p>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
      <AnimatePresence>
        {comboLabelDisplay && (
          <motion.div initial={{ scale: 0, opacity: 0, y: 20 }} animate={{ scale: 1, opacity: 1, y: 0 }} exit={{ scale: 0, opacity: 0 }} className="absolute top-1/2 left-1/2 -translate-x-1/2 z-50 pointer-events-none">
            <div className="bg-gradient-to-r from-cyan-400 to-blue-500 rounded-full px-8 py-3 shadow-2xl">
              <p className="font-display font-bold text-white text-3xl">{comboLabelDisplay}</p>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="flex items-center justify-center gap-3 px-4 py-3 bg-black/30 backdrop-blur-sm z-30">
        <button onClick={() => { if (boosters.hammer > 0) setActiveBooster(activeBooster === 'hammer' ? null : 'hammer'); }} disabled={boosters.hammer <= 0} className={`relative w-12 h-12 rounded-xl flex items-center justify-center transition-all ${activeBooster === 'hammer' ? 'bg-amber-500 scale-110' : boosters.hammer > 0 ? 'bg-white/10 hover:bg-white/20' : 'bg-white/5 opacity-30'}`}>
          <Hammer className="w-5 h-5 text-white" />
          {boosters.hammer > 0 && <span className="absolute -top-1 -right-1 bg-amber-500 text-white text-xs font-bold rounded-full w-5 h-5 flex items-center justify-center">{boosters.hammer}</span>}
        </button>
        <button onClick={handleShuffle} disabled={boosters.shuffle <= 0 || isResolving} className={`relative w-12 h-12 rounded-xl flex items-center justify-center transition-all ${boosters.shuffle > 0 ? 'bg-white/10 hover:bg-white/20' : 'bg-white/5 opacity-30'}`}>
          <ShuffleIcon className="w-5 h-5 text-white" />
          {boosters.shuffle > 0 && <span className="absolute -top-1 -right-1 bg-blue-500 text-white text-xs font-bold rounded-full w-5 h-5 flex items-center justify-center">{boosters.shuffle}</span>}
        </button>
        <button onClick={handleExtraMoves} disabled={boosters.extraMoves <= 0 || isResolving} className={`relative w-12 h-12 rounded-xl flex items-center justify-center transition-all ${boosters.extraMoves > 0 ? 'bg-white/10 hover:bg-white/20' : 'bg-white/5 opacity-30'}`}>
          <Zap className="w-5 h-5 text-white" />
          {boosters.extraMoves > 0 && <span className="absolute -top-1 -right-1 bg-cyan-500 text-white text-xs font-bold rounded-full w-5 h-5 flex items-center justify-center">{boosters.extraMoves}</span>}
        </button>
      </div>

      <AnimatePresence>
        {gameState === 'won' && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="absolute inset-0 z-[60] bg-black/70 backdrop-blur-sm flex items-center justify-center">
            <motion.div initial={{ scale: 0.5, y: 50 }} animate={{ scale: 1, y: 0 }} transition={{ type: 'spring', stiffness: 200, damping: 15 }} className="bg-gradient-to-b from-slate-800 to-slate-900 rounded-3xl p-8 max-w-xs w-full mx-4 text-center border-2 border-cyan-300/30 shadow-2xl">
              <h2 className="font-display text-3xl font-bold text-white mb-2">Level Complete!</h2>
              <div className="flex justify-center gap-2 mb-4">
                {[0, 1, 2].map((i) => (
                  <motion.div key={i} initial={{ scale: 0, rotate: 0 }} animate={{ scale: 1, rotate: 360 }} transition={{ delay: i * 0.2, type: 'spring', stiffness: 200 }}>
                    <Star className={`w-12 h-12 ${i < stars ? 'text-amber-400 fill-amber-400' : 'text-white/20'}`} />
                  </motion.div>
                ))}
              </div>
              <p className="text-cyan-300 font-display text-xl mb-6">{score.toLocaleString()} pts</p>
              <button onClick={() => props.onNextLevel()} className="w-full py-3 rounded-full bg-gradient-to-r from-cyan-400 to-teal-500 text-white font-display font-bold text-lg hover:scale-105 transition-transform shadow-lg">
                Next
              </button>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {gameState === 'lost' && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="absolute inset-0 z-[60] bg-black/70 backdrop-blur-sm flex items-center justify-center">
            <motion.div initial={{ scale: 0.5 }} animate={{ scale: 1 }} className="bg-gradient-to-b from-slate-800 to-slate-900 rounded-3xl p-8 max-w-xs w-full mx-4 text-center border-2 border-red-300/30 shadow-2xl">
              <h2 className="font-display text-3xl font-bold text-white mb-2">Out of Moves</h2>
              <p className="text-red-300 mb-6">Try again!</p>
              <button onClick={() => props.onExit()} className="w-full py-3 rounded-full bg-gradient-to-r from-red-400 to-pink-500 text-white font-display font-bold text-lg hover:scale-105 transition-transform shadow-lg">
                Back to Map
              </button>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
