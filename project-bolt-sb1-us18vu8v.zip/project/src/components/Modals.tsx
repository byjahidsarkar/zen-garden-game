import { motion } from 'framer-motion';
import { Heart, Gift, Star } from 'lucide-react';
import { audio } from '../engine/audio';

export function OutOfLivesModal({ onWatchAd, onHome }: { onWatchAd: () => void; onHome: () => void }) {
  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm">
      <motion.div initial={{ scale: 0.5, y: 50 }} animate={{ scale: 1, y: 0 }} transition={{ type: 'spring', stiffness: 200, damping: 15 }} className="bg-gradient-to-b from-slate-800 to-slate-900 rounded-3xl p-6 max-w-xs w-full mx-4 text-center border-2 border-red-300/30">
        <Heart className="w-12 h-12 text-red-400 mx-auto mb-3" />
        <h2 className="font-display text-2xl font-bold text-white mb-2">Out of Lives</h2>
        <p className="text-white/60 mb-4">Watch a short ad to get +1 life, or return to the map.</p>
        <div className="flex flex-col gap-2">
          <button onClick={() => { audio.playClick(); onWatchAd(); }} className="w-full py-3 rounded-full bg-gradient-to-r from-cyan-400 to-teal-500 text-white font-display font-bold hover:scale-105 transition-transform">Watch Ad (+1 Life)</button>
          <button onClick={() => { audio.playClick(); onHome(); }} className="w-full py-3 rounded-full bg-white/10 text-white font-display font-bold hover:bg-white/20 transition-colors">Back to Map</button>
        </div>
      </motion.div>
    </motion.div>
  );
}

export function DailyGiftModal({ onClaim, onClose }: { onClaim: () => void; onClose: () => void }) {
  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm">
      <motion.div initial={{ scale: 0.5, y: 50 }} animate={{ scale: 1, y: 0 }} transition={{ type: 'spring', stiffness: 200, damping: 15 }} className="bg-gradient-to-b from-slate-800 to-slate-900 rounded-3xl p-6 max-w-xs w-full mx-4 text-center border-2 border-amber-300/30">
        <motion.div animate={{ rotate: [0, -10, 10, 0] }} transition={{ duration: 2, repeat: Infinity }}><Gift className="w-16 h-16 text-amber-400 mx-auto mb-3" /></motion.div>
        <h2 className="font-display text-2xl font-bold text-white mb-2">Daily Gift!</h2>
        <p className="text-white/60 mb-4">Open your daily gift for a random reward!</p>
        <button onClick={() => { audio.playClick(); onClaim(); }} className="w-full py-3 rounded-full bg-gradient-to-r from-amber-400 to-orange-500 text-white font-display font-bold text-lg hover:scale-105 transition-transform shadow-lg">Open Gift</button>
        <button onClick={onClose} className="mt-2 text-white/40 text-sm hover:text-white">Not now</button>
      </motion.div>
    </motion.div>
  );
}

export function RewardRevealModal({ rewardText, onClose }: { rewardText: string; onClose: () => void }) {
  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm">
      <motion.div initial={{ scale: 0 }} animate={{ scale: 1 }} transition={{ type: 'spring', stiffness: 200, damping: 12 }} className="bg-gradient-to-b from-slate-800 to-slate-900 rounded-3xl p-8 max-w-xs w-full mx-4 text-center border-2 border-cyan-300/30">
        <motion.div animate={{ scale: [1, 1.2, 1], rotate: [0, 10, -10, 0] }} transition={{ duration: 0.6, repeat: 2 }}><Star className="w-16 h-16 text-amber-400 fill-amber-400 mx-auto mb-3" /></motion.div>
        <h2 className="font-display text-2xl font-bold text-white mb-2">You got...</h2>
        <p className="font-display text-3xl font-bold text-cyan-300 mb-4">{rewardText}</p>
        <button onClick={() => { audio.playClick(); onClose(); }} className="w-full py-3 rounded-full bg-gradient-to-r from-cyan-400 to-teal-500 text-white font-display font-bold text-lg hover:scale-105 transition-transform">Collect</button>
      </motion.div>
    </motion.div>
  );
}
