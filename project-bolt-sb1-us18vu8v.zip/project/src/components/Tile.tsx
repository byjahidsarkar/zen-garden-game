import { motion } from 'framer-motion';
import { BENGALI_CHARS, TILE_COLORS, SPECIAL_STRIPED_H, SPECIAL_STRIPED_V, SPECIAL_WRAPPED, SPECIAL_COLOR_BOMB } from '../engine/types';
import type { Cell } from '../engine/types';

type Props = {
  cell: Cell;
  dragging: boolean;
  dragOffset: { x: number; y: number } | null;
  onPointerDown: (e: React.PointerEvent) => void;
};

const SPRING = { type: 'spring' as const, stiffness: 500, damping: 24, mass: 0.8 };
const BOUNCE_SPRING = { type: 'spring' as const, stiffness: 300, damping: 12, mass: 0.6 };

export function Tile({ cell, dragging, dragOffset, onPointerDown }: Props) {
  const isEmpty = cell.type === -1;
  const typeIdx = Math.max(0, Math.min(cell.type, TILE_COLORS.length - 1));
  const color = TILE_COLORS[typeIdx];
  const char = BENGALI_CHARS[typeIdx];

  if (isEmpty) return <div className="pointer-events-none" />;

  const offset = dragOffset ?? { x: 0, y: 0 };
  const isBouncing = dragOffset !== null && !dragging;

  return (
    <div style={{ perspective: 300 }} className="w-full h-full">
      <motion.div
        layout
        initial={{ scale: 0, opacity: 0, y: -40 }}
        animate={{
          scale: dragging ? 1.15 : 1,
          opacity: 1,
          x: offset.x,
          y: offset.y,
          rotate: dragging ? 4 : 0,
          zIndex: dragging ? 100 : 10,
        }}
        exit={{ scale: 0, opacity: 0, rotate: 90 }}
        transition={isBouncing ? BOUNCE_SPRING : SPRING}
        onPointerDown={onPointerDown}
        className="relative flex items-center justify-center rounded-2xl cursor-pointer"
        style={{
          width: '100%',
          height: '100%',
          background: `radial-gradient(circle at 30% 25%, ${lighten(color, 40)} 0%, ${color} 45%, ${darken(color, 25)} 100%)`,
          boxShadow: dragging
            ? `0 8px 24px rgba(0,0,0,0.5), 0 0 0 3px rgba(255,255,255,0.5), inset 0 2px 4px rgba(255,255,255,0.4), inset 0 -4px 8px rgba(0,0,0,0.2)`
            : `0 3px 8px rgba(0,0,0,0.3), inset 0 2px 4px rgba(255,255,255,0.35), inset 0 -4px 8px rgba(0,0,0,0.2)`,
          touchAction: 'none',
        }}
      >
        <div
          className="absolute pointer-events-none rounded-2xl"
          style={{
            top: '8%', left: '12%', right: '12%', height: '35%',
            background: 'linear-gradient(180deg, rgba(255,255,255,0.5) 0%, rgba(255,255,255,0.1) 60%, rgba(255,255,255,0) 100%)',
            borderRadius: '40% 40% 50% 50%',
          }}
        />

        {cell.special === SPECIAL_STRIPED_H && (
          <div className="absolute inset-0 rounded-2xl pointer-events-none overflow-hidden">
            <div className="absolute inset-0" style={{ background: 'repeating-linear-gradient(0deg, transparent 0px, transparent 5px, rgba(255,255,255,0.45) 5px, rgba(255,255,255,0.45) 9px)' }} />
          </div>
        )}
        {cell.special === SPECIAL_STRIPED_V && (
          <div className="absolute inset-0 rounded-2xl pointer-events-none overflow-hidden">
            <div className="absolute inset-0" style={{ background: 'repeating-linear-gradient(90deg, transparent 0px, transparent 5px, rgba(255,255,255,0.45) 5px, rgba(255,255,255,0.45) 9px)' }} />
          </div>
        )}
        {cell.special === SPECIAL_WRAPPED && (
          <motion.div
            className="absolute inset-0 rounded-2xl pointer-events-none"
            animate={{ boxShadow: [`0 0 8px ${color}88`, `0 0 24px ${color}`, `0 0 8px ${color}88`] }}
            transition={{ duration: 1.2, repeat: Infinity }}
            style={{ border: '2px solid rgba(255,255,255,0.5)', borderRadius: '16px' }}
          />
        )}
        {cell.special === SPECIAL_COLOR_BOMB && (
          <motion.div
            className="absolute inset-1 rounded-full pointer-events-none"
            animate={{ rotate: 360 }}
            transition={{ duration: 3, repeat: Infinity, ease: 'linear' }}
            style={{ background: `conic-gradient(${TILE_COLORS.slice(0, 8).join(', ')}, ${TILE_COLORS[0]})`, opacity: 0.65, borderRadius: '50%' }}
          />
        )}

        <span
          className="font-bengali font-bold pointer-events-none relative"
          style={{
            fontSize: 'clamp(1.1rem, 4.5vw, 2rem)',
            color: 'rgba(255,255,255,0.98)',
            textShadow: `0 2px 4px rgba(0,0,0,0.4), 0 0 10px ${color}55`,
          }}
        >
          {char}
        </span>
      </motion.div>
    </div>
  );
}

function lighten(hex: string, amt: number): string {
  const n = parseInt(hex.replace('#', ''), 16);
  return `rgb(${Math.min(255, (n >> 16) + amt)}, ${Math.min(255, ((n >> 8) & 0xff) + amt)}, ${Math.min(255, (n & 0xff) + amt)})`;
}
function darken(hex: string, amt: number): string {
  const n = parseInt(hex.replace('#', ''), 16);
  return `rgb(${Math.max(0, (n >> 16) - amt)}, ${Math.max(0, ((n >> 8) & 0xff) - amt)}, ${Math.max(0, (n & 0xff) - amt)})`;
}
