import { useRef, useEffect, useMemo, useState } from 'react';
import { motion } from 'framer-motion';
import { Star, Lock, Crown, Heart, Coins } from 'lucide-react';
import { useGameStore } from '../store/gameStore';
import { getDifficulty } from '../engine/board';
import { MAX_LIVES } from '../engine/types';
import type { LevelResult } from '../engine/types';

type Props = { onPlay: (level: number) => void };

const DECORATIONS = ['🌸', '🍃', '✨', '🦋', '🌿', '⭐', '🌷', '🍄'];

function getLevelPosition(level: number, containerWidth: number): { x: number; y: number } {
  const cycle = (level - 1) % 8;
  const section = Math.floor((level - 1) / 8);
  const baseY = section * 520;
  const goRight = section % 2 === 0;
  const amplitude = containerWidth * 0.32;
  const centerX = containerWidth / 2;
  const positions = [
    { x: -amplitude * 0.8 }, { x: -amplitude * 0.3 }, { x: amplitude * 0.3 }, { x: amplitude * 0.8 },
    { x: amplitude * 0.6 }, { x: amplitude * 0.2 }, { x: -amplitude * 0.2 }, { x: -amplitude * 0.6 },
  ];
  const xOff = goRight ? positions[cycle].x : -positions[cycle].x;
  const yOff = cycle * 65;
  return { x: centerX + xOff, y: baseY + yOff + 80 };
}

function buildPath(points: { x: number; y: number }[]): string {
  if (points.length < 2) return '';
  let d = `M ${points[0].x} ${points[0].y}`;
  for (let i = 1; i < points.length; i++) {
    const prev = points[i - 1];
    const curr = points[i];
    const dy = curr.y - prev.y;
    const cp1x = prev.x;
    const cp1y = prev.y + dy * 0.5;
    const cp2x = curr.x;
    const cp2y = curr.y - dy * 0.5;
    d += ` C ${cp1x} ${cp1y}, ${cp2x} ${cp2y}, ${curr.x} ${curr.y}`;
  }
  return d;
}

export function WorldMap({ onPlay }: Props) {
  const highestLevel = useGameStore((s) => s.highestLevel);
  const lives = useGameStore((s) => s.lives);
  const coins = useGameStore((s) => s.coins);
  const levelResults = useGameStore((s) => s.levelResults);

  const scrollRef = useRef<HTMLDivElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const [containerWidth, setContainerWidth] = useState(400);

  useEffect(() => {
    if (containerRef.current) {
      setContainerWidth(containerRef.current.getBoundingClientRect().width);
    }
    const onResize = () => {
      if (containerRef.current) setContainerWidth(containerRef.current.getBoundingClientRect().width);
    };
    window.addEventListener('resize', onResize);
    return () => window.removeEventListener('resize', onResize);
  }, []);

  const levels = useMemo(() => Array.from({ length: Math.min(highestLevel + 3, 50) }, (_, i) => i + 1), [highestLevel]);
  const levelPositions = useMemo(() => levels.map((l) => ({ level: l, ...getLevelPosition(l, containerWidth) })), [levels, containerWidth]);
  const pathD = useMemo(() => buildPath(levelPositions), [levelPositions]);

  useEffect(() => {
    if (scrollRef.current && containerWidth > 0) {
      const el = scrollRef.current.querySelector(`[data-level="${highestLevel}"]`);
      el?.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }
  }, [highestLevel, containerWidth]);

  const totalHeight = levelPositions.length > 0 ? levelPositions[levelPositions.length - 1].y + 120 : 400;

  return (
    <div className="game-container bg-gradient-to-b from-slate-900 via-indigo-950 to-slate-900 flex flex-col">
      <div className="flex items-center justify-between px-4 py-3 bg-black/30 backdrop-blur-sm z-20">
        <span className="font-display font-bold text-white text-lg">Bengali Match</span>
        <div className="flex items-center gap-1 bg-amber-500/20 rounded-full px-3 py-1.5 border border-amber-400/20">
          <Coins className="w-4 h-4 text-amber-400" />
          <span className="font-display font-bold text-amber-200 text-sm">{coins.toLocaleString()}</span>
        </div>
      </div>
      <div className="flex items-center justify-center gap-2 py-2 bg-black/15 z-20">
        <Heart className="w-4 h-4 text-red-400" />
        <span className="text-white font-display font-bold text-sm">{lives} / {MAX_LIVES}</span>
      </div>

      <div ref={containerRef} className="flex-1 relative overflow-hidden">
        <div ref={scrollRef} className="absolute inset-0 overflow-y-auto px-4 py-4 z-10">
          <div className="relative" style={{ width: '100%', height: totalHeight }}>
            {containerWidth > 0 && (
              <svg className="absolute inset-0 pointer-events-none" style={{ width: '100%', height: totalHeight, overflow: 'visible' }}>
                <path d={pathD} fill="none" stroke="rgba(0,0,0,0.3)" strokeWidth={28} strokeLinecap="round" transform="translate(0, 4)" />
                <path d={pathD} fill="none" stroke="url(#pathGrad)" strokeWidth={24} strokeLinecap="round" strokeDasharray="2 10" />
                <path d={pathD} fill="none" stroke="rgba(255,255,255,0.15)" strokeWidth={6} strokeLinecap="round" />
                <defs>
                  <linearGradient id="pathGrad" x1="0" y1="0" x2="1" y2="1">
                    <stop offset="0%" stopColor="#0f766e" />
                    <stop offset="50%" stopColor="#0891b2" />
                    <stop offset="100%" stopColor="#0f766e" />
                  </linearGradient>
                </defs>
              </svg>
            )}

            {levelPositions.map((pos, i) => {
              if (i === 0) return null;
              const decor = DECORATIONS[(i - 1) % DECORATIONS.length];
              const dx = pos.x + Math.sin(i * 1.7) * 45;
              const dy = pos.y - 35 + Math.cos(i * 2.3) * 18;
              return (
                <motion.div
                  key={`decor-${i}`}
                  className="absolute pointer-events-none text-2xl"
                  style={{ left: dx, top: dy, transform: 'translate(-50%, -50%)' }}
                  initial={{ opacity: 0, scale: 0 }}
                  animate={{ opacity: 0.5, scale: 1 }}
                  transition={{ delay: i * 0.05, type: 'spring' }}
                >
                  {decor}
                </motion.div>
              );
            })}

            {levelPositions.map((pos) => {
              const level = pos.level;
              const isUnlocked = level <= highestLevel;
              const result: LevelResult | undefined = levelResults[level];
              const stars = result?.stars ?? 0;
              const isCurrent = level === highestLevel;
              const diff = getDifficulty(level);
              return (
                <motion.div
                  key={level}
                  data-level={level}
                  className="absolute"
                  style={{ left: pos.x, top: pos.y, transform: 'translate(-50%, -50%)' }}
                  initial={{ scale: 0.8, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  transition={{ type: 'spring', stiffness: 200, damping: 15 }}
                >
                  {isUnlocked && (
                    <div className="absolute -bottom-2 left-1/2 -translate-x-1/2 w-16 h-3 rounded-full"
                      style={{ background: isCurrent ? 'rgba(94,234,212,0.3)' : 'rgba(255,255,255,0.1)', filter: 'blur(4px)' }} />
                  )}
                  <button
                    onClick={() => { if (isUnlocked) onPlay(level); }}
                    disabled={!isUnlocked}
                    className={`relative w-16 h-16 rounded-full flex flex-col items-center justify-center transition-all ${
                      isUnlocked
                        ? isCurrent
                          ? 'bg-gradient-to-br from-cyan-400 to-teal-600 shadow-lg shadow-cyan-500/50 hover:scale-110 animate-pulse-glow'
                          : 'bg-gradient-to-br from-slate-600 to-slate-800 hover:scale-110'
                        : 'bg-slate-800/50'
                    }`}
                    style={{ border: isCurrent ? '2px solid rgba(94,234,212,0.6)' : '2px solid rgba(255,255,255,0.1)' }}
                  >
                    {isUnlocked ? (
                      <>
                        <span className="font-display font-bold text-white text-base">{level}</span>
                        {isCurrent && <Crown className="w-4 h-4 text-amber-400 absolute -top-3 -right-1" />}
                        {stars > 0 && (
                          <div className="flex gap-0.5 mt-0.5">
                            {[0, 1, 2].map((i) => <Star key={i} className={`w-2 h-2 ${i < stars ? 'text-amber-400 fill-amber-400' : 'text-white/20'}`} />)}
                          </div>
                        )}
                      </>
                    ) : (
                      <Lock className="w-5 h-5 text-white/30" />
                    )}
                  </button>
                  {isUnlocked && <span className="absolute -bottom-5 text-[8px] text-white/40 whitespace-nowrap font-display">{diff.tileTypes} colors · {diff.moves} moves</span>}
                </motion.div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}
