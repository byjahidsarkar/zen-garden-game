import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Coins, Heart, Hammer, Shuffle, Plus, Gift } from 'lucide-react';
import { audio } from '../engine/audio';

export type SpinReward =
  | { type: 'coins'; amount: number; label: string; color: string; icon: 'coins' }
  | { type: 'lives'; amount: number; label: string; color: string; icon: 'lives' }
  | { type: 'hammer'; amount: number; label: string; color: string; icon: 'hammer' }
  | { type: 'shuffle'; amount: number; label: string; color: string; icon: 'shuffle' }
  | { type: 'extraMoves'; amount: number; label: string; color: string; icon: 'extraMoves' };

const SEGMENTS: SpinReward[] = [
  { type: 'coins', amount: 50, label: '50 Coins', color: '#fbbf24', icon: 'coins' },
  { type: 'lives', amount: 1, label: '+1 Life', color: '#f87171', icon: 'lives' },
  { type: 'hammer', amount: 1, label: 'Hammer', color: '#fb923c', icon: 'hammer' },
  { type: 'coins', amount: 100, label: '100 Coins', color: '#34d399', icon: 'coins' },
  { type: 'shuffle', amount: 1, label: 'Shuffle', color: '#60a5fa', icon: 'shuffle' },
  { type: 'extraMoves', amount: 1, label: '+5 Moves', color: '#a78bfa', icon: 'extraMoves' },
  { type: 'coins', amount: 200, label: '200 Coins', color: '#f472b6', icon: 'coins' },
  { type: 'lives', amount: 2, label: '+2 Lives', color: '#22d3ee', icon: 'lives' },
];
const SEG_COUNT = SEGMENTS.length;
const SEG_ANGLE = 360 / SEG_COUNT;

type Props = { onClaim: (reward: SpinReward) => void; onClose: () => void };

export function SpinWheelModal({ onClaim, onClose }: Props) {
  const [spinning, setSpinning] = useState(false);
  const [rotation, setRotation] = useState(0);
  const [landedIndex, setLandedIndex] = useState<number | null>(null);
  const [showResult, setShowResult] = useState(false);

  const handleSpin = () => {
    if (spinning) return; audio.playBooster(); setSpinning(true); setShowResult(false);
    const targetIndex = Math.floor(Math.random() * SEG_COUNT);
    const targetAngle = targetIndex * SEG_ANGLE + SEG_ANGLE / 2;
    setRotation(rotation + 5 * 360 + (360 - targetAngle)); setLandedIndex(targetIndex);
    setTimeout(() => { setSpinning(false); setShowResult(true); audio.playWin(); }, 4100);
  };

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm">
      <motion.div initial={{ scale: 0.5, y: 50 }} animate={{ scale: 1, y: 0 }} transition={{ type: 'spring', stiffness: 200, damping: 15 }} className="bg-gradient-to-b from-slate-800 to-slate-900 rounded-3xl p-6 max-w-sm w-full mx-4 shadow-2xl border-2 border-cyan-300/30">
        <div className="flex items-center justify-between mb-4">
          <h2 className="font-display text-2xl font-bold text-white">Daily Spin Wheel</h2>
          <button onClick={onClose} disabled={spinning} className="text-white/40 hover:text-white disabled:opacity-20"><X className="w-5 h-5" /></button>
        </div>
        <div className="relative w-64 h-64 mx-auto mb-4">
          <div className="absolute top-0 left-1/2 -translate-x-1/2 z-20 w-0 h-0" style={{ borderLeft: '12px solid transparent', borderRight: '12px solid transparent', borderTop: '20px solid #ffd166', filter: 'drop-shadow(0 2px 4px rgba(0,0,0,0.4))' }} />
          <motion.div className="absolute inset-0 rounded-full border-4 border-white/20 overflow-hidden" animate={{ rotate: rotation }} transition={spinning ? { duration: 4, ease: [0.17, 0.67, 0.12, 0.99] } : { duration: 0 }} style={{ boxShadow: '0 8px 32px rgba(0,0,0,0.5)' }}>
            <svg viewBox="0 0 200 200" className="w-full h-full">
              {SEGMENTS.map((seg, i) => {
                const startAngle = i * SEG_ANGLE - 90; const endAngle = (i + 1) * SEG_ANGLE - 90;
                const startRad = (startAngle * Math.PI) / 180; const endRad = (endAngle * Math.PI) / 180;
                const x1 = 100 + 100 * Math.cos(startRad); const y1 = 100 + 100 * Math.sin(startRad);
                const x2 = 100 + 100 * Math.cos(endRad); const y2 = 100 + 100 * Math.sin(endRad);
                const midAngle = (startAngle + endAngle) / 2; const midRad = (midAngle * Math.PI) / 180;
                const tx = 100 + 55 * Math.cos(midRad); const ty = 100 + 55 * Math.sin(midRad);
                return (<g key={i}><path d={`M 100 100 L ${x1} ${y1} A 100 100 0 0 1 ${x2} ${y2} Z`} fill={seg.color} stroke="rgba(255,255,255,0.3)" strokeWidth="1" /><text x={tx} y={ty} fill="white" fontSize="9" fontWeight="bold" textAnchor="middle" dominantBaseline="middle" transform={`rotate(${midAngle + 90}, ${tx}, ${ty})`} style={{ textShadow: '0 1px 2px rgba(0,0,0,0.5)' }}>{seg.label}</text></g>);
              })}
              <circle cx="100" cy="100" r="18" fill="#1e293b" stroke="rgba(255,255,255,0.2)" strokeWidth="2" />
            </svg>
          </motion.div>
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 z-10 w-10 h-10 rounded-full bg-slate-800 border-2 border-white/20 flex items-center justify-center"><Gift className="w-5 h-5 text-amber-300" /></div>
        </div>
        <AnimatePresence>
          {showResult && landedIndex !== null && (<motion.div initial={{ scale: 0, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} className="text-center mb-3"><p className="text-cyan-300 text-sm font-bold mb-1">You won...</p><div className="flex items-center justify-center gap-2"><RewardIcon icon={SEGMENTS[landedIndex].icon} /><p className="font-display text-2xl font-bold text-white">{SEGMENTS[landedIndex].label}</p></div></motion.div>)}
        </AnimatePresence>
        {!showResult ? (<button onClick={handleSpin} disabled={spinning} className={`w-full py-3 rounded-full font-display font-bold text-lg transition-all ${spinning ? 'bg-white/10 text-white/40 cursor-not-allowed' : 'bg-gradient-to-r from-amber-400 to-orange-500 text-white hover:scale-105 shadow-lg'}`}>{spinning ? 'Spinning...' : 'SPIN!'}</button>) : (<button onClick={() => { audio.playClick(); onClaim(SEGMENTS[landedIndex!]); }} className="w-full py-3 rounded-full bg-gradient-to-r from-emerald-400 to-green-500 text-white font-display font-bold text-lg hover:scale-105 transition-transform shadow-lg">Collect Reward</button>)}
      </motion.div>
    </motion.div>
  );
}

function RewardIcon({ icon }: { icon: SpinReward['icon'] }) {
  const cls = 'w-6 h-6 text-white';
  if (icon === 'coins') return <Coins className={cls} />;
  if (icon === 'lives') return <Heart className={cls} />;
  if (icon === 'hammer') return <Hammer className={cls} />;
  if (icon === 'shuffle') return <Shuffle className={cls} />;
  return <Plus className={cls} />;
}
