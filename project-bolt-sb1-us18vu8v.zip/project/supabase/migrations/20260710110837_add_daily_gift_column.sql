/*
# Add last_daily_gift_at column to game_progress

1. Modified Tables
- `game_progress`
  - `last_daily_gift_at` (timestamptz, nullable) — timestamp of the last claimed daily gift; null if never claimed

2. Security
- No policy changes — the existing anon/authenticated CRUD policies on game_progress already cover this column.

3. Notes
- Uses DO $$ ... END $$ to conditionally add the column only if it does not already exist, making the migration idempotent and safe to re-run.
*/

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'game_progress' AND column_name = 'last_daily_gift_at'
  ) THEN
    ALTER TABLE game_progress ADD COLUMN last_daily_gift_at timestamptz;
  END IF;
END $$;
