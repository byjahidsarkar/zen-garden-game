/*
# Create game_progress table (single-tenant, no auth)

1. New Tables
- `game_progress`
  - `id` (int, primary key) — always 1 (singleton row for this single-tenant game)
  - `lives` (int, default 5) — current life count
  - `last_life_at` (timestamptz) — when the last life was lost, for regen
  - `boosters` (jsonb) — counts of each booster type { hammer, shuffle, extraMoves }
  - `highest_level` (int, default 1) — highest unlocked level
  - `total_score` (bigint, default 0) — cumulative score
  - `updated_at` (timestamptz)
- `level_results`
  - `level` (int, primary key)
  - `stars` (int, default 0) — 0..3
  - `best_score` (int, default 0)
  - `completed` (bool, default false)
  - `updated_at` (timestamptz)

2. Security
- Enable RLS on both tables.
- Allow anon + authenticated full CRUD because the data is intentionally shared/public (single-tenant no-auth game).
*/

CREATE TABLE IF NOT EXISTS game_progress (
  id int PRIMARY KEY DEFAULT 1,
  lives int NOT NULL DEFAULT 5,
  last_life_at timestamptz,
  boosters jsonb NOT NULL DEFAULT '{"hammer": 1, "shuffle": 1, "extraMoves": 1}'::jsonb,
  highest_level int NOT NULL DEFAULT 1,
  total_score bigint NOT NULL DEFAULT 0,
  updated_at timestamptz DEFAULT now(),
  CONSTRAINT single_row CHECK (id = 1)
);

ALTER TABLE game_progress ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_game_progress" ON game_progress;
CREATE POLICY "anon_select_game_progress" ON game_progress FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_game_progress" ON game_progress;
CREATE POLICY "anon_insert_game_progress" ON game_progress FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_game_progress" ON game_progress;
CREATE POLICY "anon_update_game_progress" ON game_progress FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_game_progress" ON game_progress;
CREATE POLICY "anon_delete_game_progress" ON game_progress FOR DELETE
  TO anon, authenticated USING (true);

CREATE TABLE IF NOT EXISTS level_results (
  level int PRIMARY KEY,
  stars int NOT NULL DEFAULT 0,
  best_score int NOT NULL DEFAULT 0,
  completed boolean NOT NULL DEFAULT false,
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE level_results ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_level_results" ON level_results;
CREATE POLICY "anon_select_level_results" ON level_results FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_level_results" ON level_results;
CREATE POLICY "anon_insert_level_results" ON level_results FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_level_results" ON level_results;
CREATE POLICY "anon_update_level_results" ON level_results FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_level_results" ON level_results;
CREATE POLICY "anon_delete_level_results" ON level_results FOR DELETE
  TO anon, authenticated USING (true);

-- Seed the singleton progress row.
INSERT INTO game_progress (id) VALUES (1)
ON CONFLICT (id) DO NOTHING;
